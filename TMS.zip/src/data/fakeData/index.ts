import { fakeDataInfo } from './organizations';

export { fakeDataInfo };
