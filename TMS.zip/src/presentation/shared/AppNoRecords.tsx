const AppNoRecords = () => {
	return (
		<div className='p-3 text-center text-gray-500 border rounded-md'>
			There are no records to display
		</div>
	);
};

export default AppNoRecords;
