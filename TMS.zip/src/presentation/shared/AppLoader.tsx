import './styles.css';

const AppLoader = () => {
	return <span className='loader'></span>;
};

export default AppLoader;
