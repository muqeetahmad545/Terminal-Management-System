import './App.css';

function App() {
	return (
		<>
			<p>App</p>
		</>
	);
}

export default App;
